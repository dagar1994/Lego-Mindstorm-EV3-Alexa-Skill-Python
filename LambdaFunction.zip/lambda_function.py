# -*- coding: utf-8 -*-
"""
Alexa Gadgets Toolkit Control Alexa Skill
"""

from __future__ import print_function
import random
import requests
import json



def build_speechlet_response(title, output, reprompt_text, should_end_session):
    return {
        'outputSpeech': {
            'type': 'PlainText',
            'text': output
        },
        'card': {
            'type': 'Simple',
            'title':  title,
            'content':  output
        },
        'reprompt': {
            'outputSpeech': {
                'type': 'PlainText',
                'text': reprompt_text
            }
        },
        'shouldEndSession': should_end_session
    }
    
def build_speechlet_response_start_listener(title, output, reprompt_text, should_end_session,endpointId):
    return {
        'outputSpeech': {
            'type': 'SSML',
            'ssml': '<speak>' + output + '</speak>'
        },
        'card': {
            'type': 'Simple',
            'title':  title,
            'content':  output
        },
        'reprompt': {
            'outputSpeech': {
                'type': 'PlainText',
                'text': reprompt_text
            }
        },
        "directives": [
            {
                "type": "CustomInterfaceController.StartEventHandler",
                "token": "voxo1234",
                "expiration": {
                    "durationInMilliseconds": 20000,
                    "expirationPayload": {
                        "gameOverSpeech": "Game over! Would you like to hear your stats?"
                    }
                },
                "eventFilter": {
                    "filterExpression":{
                        "and": [
                            {"==": [{"var": "header.namespace"}, "Custom.Mindstorms.Gadget"]},
                            { "==": [{ "var": "endpoint.endpointId" }, endpointId]}
                        ]
                    },
                    "filterMatchAction": "SEND_AND_TERMINATE"  
                }
            }
        ],
        'shouldEndSession': should_end_session
    }

def build_speechlet_response_robo(title, output, reprompt_text, should_end_session,endpointId,typeOfAction):
    return {
        'outputSpeech': {
            'type': 'PlainText',
            'text': output
        },
        'card': {
            'type': 'Simple',
            'title':  title,
            'content':  output
        },
        'reprompt': {
            'outputSpeech': {
                'type': 'PlainText',
                'text': reprompt_text
            }
        },
        'directives': [
            {
                "type": "CustomInterfaceController.SendDirective",
                "endpoint": {
                  "endpointId": endpointId
                },
                "header": {
                  "namespace": "Custom.Mindstorms.Gadget",
                  "name": "Control"
                },
                "payload": { 
                  "direction": "clockwise",
                  "times": 5,
                  "type" : typeOfAction
                }
              }
            ],
        'shouldEndSession': should_end_session
    }


def build_response(session_attributes, speechlet_response):
    return {
        'version': '1.0',
        'sessionAttributes': session_attributes,
        'response': speechlet_response
    }


# --------------- Functions that control the skill's behavior ------------------


def help_response():
    session_attributes = {}
    card_title = "Help"
    speech_output = """
		Say, Alexa, kante facts
			""".strip() 
    # If the user either does not reply to the welcome message or says something
    # that is not understood, they will be prompted again with this text.
    reprompt_text = speech_output 
    should_end_session = True
    return build_response(session_attributes, build_speechlet_response(
        card_title, speech_output, reprompt_text, should_end_session))


def cancel_response():
    session_attributes = {}
    card_title = "Thank you"
    speech_output = """
	Come back again for new N'Golo Kante fact.
			""".strip() 
    reprompt_text = speech_output
    should_end_session = True
    return build_response(session_attributes, build_speechlet_response(
        card_title, speech_output, reprompt_text, should_end_session))



def checkGadgetConnectivity(apiEndpoint,accessToken):
    headers = {
    'Authorization': 'Bearer ' + accessToken,
    'Content-Type': 'application/json',
        }
    
    response = requests.get(apiEndpoint + '/v1/endpoints', headers=headers, verify=False)
    print(response)
    print(response.text)
    respJson = json.loads(response.text)
    try:
        endpointId = respJson["endpoints"][0]["endpointId"]
    except:
        endpointId = "X"
    return endpointId

def startSentryMode(intent,session):
    endpointId = session["attributes"]["endpointId"]
    card_title = "Thank you"
    speech_output = "Sentry Mode activated. State listener started <audio src='soundbank://soundlibrary/backgrounds_ambience/traffic/traffic_06'/> <audio src='soundbank://soundlibrary/backgrounds_ambience/traffic/traffic_06'/> <audio src='soundbank://soundlibrary/backgrounds_ambience/traffic/traffic_06'/>"
    # Setting this to true ends the session and exits the skill.
    should_end_session = False
    return build_response(session["attributes"], build_speechlet_response_start_listener(
        card_title, speech_output, None, should_end_session, endpointId))

def listenerExpired(session):
    endpointId = session["attributes"]["endpointId"]
    card_title = "Thank you"
    speech_output = "Sentry mode expired. Sentry Mode activated again." 
    # Setting this to true ends the session and exits the skill.
    should_end_session = False
    return build_response(session["attributes"], build_speechlet_response_start_listener(
        card_title, speech_output, None, should_end_session, endpointId))


def receivedEventFromGadget(session,event):
    print("Event")
    print(event)
    session_attributes = session["attributes"]
    card_title = "Thank you"
    speech_output = """
	Received an event back from Sentry.
			""".strip() 
    reprompt_text = speech_output
    should_end_session = True
    return build_response(session_attributes, build_speechlet_response(
        card_title, speech_output, reprompt_text, should_end_session))

	
def caller(intent,session,typeOfAction):
    endpointId = session["attributes"]["endpointId"]
    card_title = "Thank you"
    speech_output = "Command given to the robot" 
    # Setting this to true ends the session and exits the skill.
    should_end_session = False
    return build_response(session["attributes"], build_speechlet_response_robo(
        card_title, speech_output, None, should_end_session,endpointId,typeOfAction))

def get_welcome_response(event):
    """ If we wanted to initialize the session to have some attributes we could
    add those here
    """
    apiEndpoint = event["context"]["System"]["apiEndpoint"]
    accessToken = event["context"]["System"]["apiAccessToken"]
    endpointId = checkGadgetConnectivity(apiEndpoint,accessToken)
    
    if endpointId == "X":
        speech_output = "Hello, welcome to Gadgets Toolkit Test. No alexa gadget is connected."
        session_attributes = {}
        card_title = "Robot Controller"
        reprompt_text = speech_output
        should_end_session = True
    else:
        speech_output = "Hello, welcome to Gadgets Toolkit Test. Tell me a command to perform."
        session_attributes = {"endpointId" : endpointId}
        card_title = "Robot Controller"
        reprompt_text = speech_output
        should_end_session = False
    return build_response(session_attributes, build_speechlet_response(
        card_title, speech_output, reprompt_text, should_end_session))


def handle_session_end_request():
    card_title = "Thank you"
    speech_output = "Come back again for new N'Golo Kante fact." 
    # Setting this to true ends the session and exits the skill.
    should_end_session = True
    return build_response({}, build_speechlet_response(
        card_title, speech_output, None, should_end_session))



def on_session_started(session_started_request, session):
    """ Called when the session starts """

    print("on_session_started requestId=" + session_started_request['requestId']
          + ", sessionId=" + session['sessionId'])


def on_launch(launch_request, session, event):
    """ Called when the user launches the skill without specifying what they
    want
    """

    print("on_launch requestId=" + launch_request['requestId'] +
          ", sessionId=" + session['sessionId'])
    # Dispatch to your skill's launch
    return get_welcome_response(event)


def on_intent(intent_request, session):
    """ Called when the user specifies an intent for this skill """

    print("on_intent requestId=" + intent_request['requestId'] +
          ", sessionId=" + session['sessionId'])

    intent = intent_request['intent']
    intent_name = intent_request['intent']['name']

    # Dispatch to your skill's intent handlers
    if intent_name == "AMAZON.HelpIntent":
        return help_response()
    elif intent_name == "AMAZON.CancelIntent":
	    return cancel_response()
    elif intent_name == "AMAZON.StopIntent":
        return cancel_response()
    elif intent_name == "" or intent_name == "AMAZON.StopIntent":
        return handle_session_end_request()
    elif intent_name == "helloIntent":
        return caller(intent,session,"spin")
    elif intent_name == "moveForwardIntent":
        return caller(intent,session,"movef")
    elif intent_name == "moveBackwardIntent":
        return caller(intent,session,"moveb")
    elif intent_name == "moveRightIntent":
        return caller(intent,session,"mover")
    elif intent_name == "moveLeftIntent":
        return caller(intent,session,"movel")
    elif intent_name == "startSentryMode":
        return startSentryMode(intent,session)
    else:
        raise ValueError("Invalid intent")


def on_session_ended(session_ended_request, session):
    """ Called when the user ends the session.

    Is not called when the skill returns should_end_session=true
    """
    print("on_session_ended requestId=" + session_ended_request['requestId'] +
          ", sessionId=" + session['sessionId'])
    # add cleanup logic here


# --------------- Main handler ------------------

def lambda_handler(event, context):
    """ Route the incoming request based on type (LaunchRequest, IntentRequest,
    etc.) The JSON body of the request is provided in the event parameter.
    """
    print("event.session.application.applicationId=" +
          event['session']['application']['applicationId'])
          
    print("Event received")
    print(event)
    print("Event Ended")

    """
    Uncomment this if statement and populate with your skill's application ID to
    prevent someone else from configuring a skill that sends requests to this
    function.
    """
    # if (event['session']['application']['applicationId'] !=
    #         "amzn1.echo-sdk-ams.app.[unique-value-here]"):
    #     raise ValueError("Invalid Application ID")

    if event['session']['new']:
        on_session_started({'requestId': event['request']['requestId']},
                           event['session'])
    if event['request']['type'] == "LaunchRequest":
        return on_launch(event['request'], event['session'], event)
    elif event['request']['type'] == "IntentRequest":
        return on_intent(event['request'], event['session'])
    elif event['request']['type'] == "SessionEndedRequest":
        return on_session_ended(event['request'], event['session'])
    elif event['request']['type'] == "CustomInterfaceController.Expired":
        return listenerExpired(event['session'])
    elif event['request']['type'] == "CustomInterfaceController.EventsReceived":
        return receivedEventFromGadget(event['session'],event["request"]["events"][0])
    
